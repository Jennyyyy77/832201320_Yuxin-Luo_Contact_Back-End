package cn.zwz.data.service;

import cn.zwz.data.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 角色 服务层接口
 * @author Yuxin Luo
 */
public interface IRoleService extends IService<Role> {

}
