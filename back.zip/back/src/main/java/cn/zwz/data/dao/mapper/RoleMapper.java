package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 角色 数据链路层接口
 * @author Yuxin Luo
 */
public interface RoleMapper extends BaseMapper<Role> {
}
