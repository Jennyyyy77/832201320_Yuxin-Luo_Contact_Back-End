package cn.zwz.data.service;

import cn.zwz.data.entity.Department;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 部门 服务层接口
 * @author Yuxin Luo
 */
public interface IDepartmentService extends IService<Department> {

}
