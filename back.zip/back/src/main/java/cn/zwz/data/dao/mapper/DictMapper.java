package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Dict;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 数据字典 数据链路层接口
 * @author Yuxin Luo
 */
public interface DictMapper extends BaseMapper<Dict> {
}
