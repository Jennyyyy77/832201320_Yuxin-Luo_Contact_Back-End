package cn.zwz.data.service;

import cn.zwz.data.entity.DictData;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 数据字典值 服务层接口
 * @author Yuxin Luo
 */
public interface IDictDataService extends IService<DictData> {

}
