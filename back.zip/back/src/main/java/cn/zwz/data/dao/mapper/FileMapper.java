package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.File;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 系统文件 数据链路层接口
 * @author Yuxin Luo
 */
public interface FileMapper extends BaseMapper<File> {
}
